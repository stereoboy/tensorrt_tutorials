class UffException(Exception):
    pass


class UffOrdersException(UffException):
    pass


class UffReferenceException(UffException):
    pass
